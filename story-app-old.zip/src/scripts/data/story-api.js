// src/scripts/data/story-api.js

const STORY_API_BASE_URL = 'https://story-api.dicoding.dev/v1';

class StoryApi {
    // --- Fungsi Helper untuk Token ---
    static _setToken(token) {
        sessionStorage.setItem('story-token', token);
    }

    static _getToken() {
        return sessionStorage.getItem('story-token');
    }

    static _removeToken() {
        sessionStorage.removeItem('story-token');
    }

    // --- Endpoint Autentikasi ---

    /**
     * Login pengguna
     * @param {string} email
     * @param {string} password
     * @returns {Promise<object>}
     */
    static async login(email, password) {
        try {
        const response = await fetch(`${STORY_API_BASE_URL}/login`, {
            method: 'POST',
            headers: {
            'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password }),
        });

        const responseJson = await response.json();

        if (responseJson.error) {
            throw new Error(responseJson.message);
        }

        // Simpan token jika berhasil
        this._setToken(responseJson.loginResult.token);
        return responseJson.loginResult;
        } catch (error) {
        console.error('Login failed:', error.message);
        throw error;
        }
    }

    /**
     * Register pengguna baru
     * @param {string} name
     * @param {string} email
     * @param {string} password
     * @returns {Promise<object>}
     */
    static async register(name, email, password) {
        try {
        const response = await fetch(`${STORY_API_BASE_URL}/register`, {
            method: 'POST',
            headers: {
            'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name, email, password }),
        });

        const responseJson = await response.json();

        if (responseJson.error) {
            throw new Error(responseJson.message);
        }

        return responseJson;
        } catch (error) {
        console.error('Register failed:', error.message);
        throw error;
        }
    }

    // --- Endpoint Cerita (Stories) ---

    /**
     * Mendapatkan semua cerita
     * @returns {Promise<array>}
     */
    static async getAllStories() {
        const token = this._getToken();
        if (!token) {
        // 401 Unauthorized - Token tidak ada
        throw new Error('401'); 
        }

        try {
        const response = await fetch(`${STORY_API_BASE_URL}/stories?location=1`, {
            method: 'GET',
            headers: {
            'Authorization': `Bearer ${token}`,
            },
        });

        if (response.status === 401) {
            // Token tidak valid
            this._removeToken();
            throw new Error('401');
        }

        const responseJson = await response.json();

        if (responseJson.error) {
            throw new Error(responseJson.message);
        }

        return responseJson.listStory;
        } catch (error) {
        console.error('Failed to fetch stories:', error.message);
        throw error;
        }
    }

    /**
   * Menambahkan cerita baru
   * @param {FormData} formData - Data form (photo, description, lat, lon)
   * @returns {Promise<object>}
   */
  static async addStory(formData) {
    const token = this._getToken();
    if (!token) {
      // 401 Unauthorized - Token tidak ada
      throw new Error('401');
    }

    try {
      const response = await fetch(`${STORY_API_BASE_URL}/stories`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      });
      
      if (response.status === 401) {
         // Token tidak valid
        this._removeToken();
        throw new Error('401');
      }

      const responseJson = await response.json();

      if (responseJson.error) {
        throw new Error(responseJson.message);
      }

      return responseJson;
    } catch (error) {
      console.error('Failed to add story:', error.message);
      throw error;
    }
  }

}

export default StoryApi;
