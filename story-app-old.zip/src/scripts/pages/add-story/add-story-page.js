import L from 'leaflet';
import StoryApi from '../../data/story-api';

class AddStoryPage {
  constructor() {
    this._map = null;
    this._selectedLat = null;
    this._selectedLon = null;
    this._mapMarker = null;
  }

  async render() {
    return `
      <section class="add-story-page">
        <h2>Tambah Cerita Baru</h2>
        <p>Bagikan momen berhargamu dan lokasinya!</p>

        <form id="add-story-form" class="add-story-form" novalidate>
          <!-- Opsi Kamera/Upload -->
          <div class="form-group">
            <label for="story-photo">Foto Cerita:</label>
            <input type="file" id="story-photo" name="photo" accept="image/*" class="form-control" required>
          </div>

          <!-- Pratinjau Gambar -->
          <img id="image-preview" src="#" alt="Pratinjau gambar" style="display: none; max-width: 100%; height: auto; margin-bottom: 1rem;">

          <div class="form-group">
            <label for="story-description">Deskripsi:</label>
            <textarea id="story-description" name="description" class="form-control" rows="5" required minlength="5"></textarea>
          </div>

          <div class="form-group">
            <label>Lokasi Cerita:</label>
            <p style="font-size: 0.9rem; margin-top: -10px; color: #555;">Klik pada peta untuk memilih lokasi.</p>
            <div id="add-story-map"></div>
          </div>
          
          <input type="hidden" id="story-lat" name="lat">
          <input type="hidden" id="story-lon" name="lon">

          <button type="submit" class="auth-button">Upload Cerita</button>

          <!-- Pesan Error -->
          <div id="error-message" class="error-message" role="alert" aria-live="assertive"></div>
        </form>
      </section>
    `;
  }

  async afterRender() {
    this._initMap();

    const photoInput = document.getElementById('story-photo');
    const imagePreview = document.getElementById('image-preview');
    photoInput.addEventListener('change', () => {
      const file = photoInput.files[0];
      if (file) {
        imagePreview.src = URL.createObjectURL(file);
        imagePreview.style.display = 'block';
        imagePreview.onload = () => {
          URL.revokeObjectURL(imagePreview.src);
        }
      }
    });

    const addStoryForm = document.getElementById('add-story-form');
    addStoryForm.addEventListener('submit', (event) => {
      event.preventDefault();
      this._handleSubmit(event);
    });
  }

  _initMap() {
    const centerLat = -2.5489;
    const centerLon = 118.0149;
    
    this._map = L.map('add-story-map').setView([centerLat, centerLon], 5);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(this._map);

    this._map.on('click', (e) => {
      const { lat, lng } = e.latlng;
      this._selectedLat = lat;
      this._selectedLon = lng;

      document.getElementById('story-lat').value = lat;
      document.getElementById('story-lon').value = lng;

      if (this._mapMarker) {
        this._map.removeLayer(this._mapMarker);
      }

      this._mapMarker = L.marker([lat, lng]).addTo(this._map)
        .bindPopup('Lokasi cerita dipilih')
        .openPopup();
    });
  }

  async _handleSubmit(event) {
    const form = event.target;
    const errorMessageElement = document.getElementById('error-message');
    
    // Reset error
    errorMessageElement.textContent = '';
    errorMessageElement.style.display = 'none';

    // Ambil data
    const photo = form.photo.files[0];
    const description = form.description.value;
    const lat = this._selectedLat;
    const lon = this._selectedLon;

    if (!photo || !description || !lat || !lon) {
      this._showError(errorMessageElement, 'Harap isi foto, deskripsi, dan pilih lokasi di peta.');
      return;
    }
    if (description.length < 5) {
      this._showError(errorMessageElement, 'Deskripsi minimal harus 5 karakter.');
      return;
    }

    try {
      // Tampilkan loading
      form.querySelector('button').textContent = 'Mengunggah...';
      form.querySelector('button').disabled = true;

      // Buat FormData
      const formData = new FormData();
      formData.append('photo', photo);
      formData.append('description', description);
      formData.append('lat', lat);
      formData.append('lon', lon);

      // Panggil API
      await StoryApi.addStory(formData);

      // Jika berhasil
      alert('Cerita baru berhasil ditambahkan!');
      window.location.hash = '#/stories';

    } catch (error) {
      this._showError(errorMessageElement, error.message);
    } finally {
      form.querySelector('button').textContent = 'Upload Cerita';
      form.querySelector('button').disabled = false;
    }
  }

  _showError(element, message) {
    element.textContent = message;
    element.style.display = 'block';
  }

  _initCameraControls() {
    this._startBtn = document.getElementById('start-camera-btn');
    this._stopBtn = document.getElementById('stop-camera-btn');
    this._captureBtn = document.getElementById('capture-btn');
    
    this._cameraContainer = document.getElementById('camera-container');
    this._videoEl = document.getElementById('camera-feed');
    this._canvasEl = document.getElementById('camera-canvas');
    this._fileUploadGroup = document.getElementById('file-upload-group');
    this._uploadDivider = document.getElementById('upload-divider');
    
    this._errorMessageElement = document.getElementById('error-message');

    this._startBtn.addEventListener('click', () => this._startCamera());
    this._stopBtn.addEventListener('click', () => this._stopCamera());
    this._captureBtn.addEventListener('click', () => this._captureImage());
  }

  async _startCamera() {
    if (!('mediaDevices' in navigator && 'getUserMedia' in navigator.mediaDevices)) {
      this._showError(this._errorMessageElement, 'Kamera tidak didukung di browser ini.');
      return;
    }

    try {
      this._stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' }
      });
      
      this._videoEl.srcObject = this._stream;
      this._videoEl.play();
      
      this._cameraContainer.style.display = 'block';
      this._startBtn.style.display = 'none';
      this._fileUploadGroup.style.display = 'none';
      this._uploadDivider.style.display = 'none';
      
    } catch (err) {
      console.error('Error accessing camera:', err);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        this._showError(this._errorMessageElement, 'Izin akses kamera ditolak.');
      } else {
         try {
            this._stream = await navigator.mediaDevices.getUserMedia({ video: true });
            this._videoEl.srcObject = this._stream;
            this._videoEl.play();
            
            this._cameraContainer.style.display = 'block';
            this._startBtn.style.display = 'none';
            this._fileUploadGroup.style.display = 'none';
            this._uploadDivider.style.display = 'none';
         } catch (fallbackErr) {
            this._showError(this._errorMessageElement, 'Gagal mengakses kamera. Pastikan izin diberikan.');
            console.error('Fallback camera error:', fallbackErr);
         }
      }
    }
  }

  _stopCamera() {
    if (this._stream) {
      this._stream.getTracks().forEach(track => track.stop());
      this._stream = null;
    }
    
    this._cameraContainer.style.display = 'none';
    this._startBtn.style.display = 'block';
    this._fileUploadGroup.style.display = 'block';
    this._uploadDivider.style.display = 'block';
  }

  _captureImage() {
    const context = this._canvasEl.getContext('2d');
    
    this._canvasEl.width = this._videoEl.videoWidth;
    this._canvasEl.height = this._videoEl.videoHeight;
    
    context.drawImage(this._videoEl, 0, 0, this._canvasEl.width, this._canvasEl.height);
    
    this._canvasEl.toBlob((blob) => {
      this._capturedFile = new File([blob], 'captured_story.png', { type: 'image/png' });
      this._displayImagePreview(this._capturedFile);
      document.getElementById('story-photo').value = '';
      this._stopCamera();
    }, 'image/png');
  }


  /**
   * Menampilkan pratinjau gambar (dari file atau kamera)
   * @param {File} file - File gambar
   */
  _displayImagePreview(file) {
    const imagePreview = document.getElementById('image-preview');
    const reader = new FileReader();
    
    reader.onload = (e) => {
      imagePreview.src = e.target.result;
      imagePreview.style.display = 'block';
    };
    
    reader.readAsDataURL(file);
  }

  async _handleSubmit(event) {
    const form = event.target;
    const errorMessageElement = document.getElementById('error-message');
    
    errorMessageElement.textContent = '';
    errorMessageElement.style.display = 'none';

    // Ambil foto dari kamera ATAU file
    const photoFromFile = form.photo.files[0];
    const photo = this._capturedFile || photoFromFile;
    
    const description = form.description.value;
    const lat = this._selectedLat;
    const lon = this._selectedLon;

    // Validasi Input
    if (!photo || !description || !lat || !lon) {
      this._showError(errorMessageElement, 'Harap isi foto, deskripsi, dan pilih lokasi di peta.');
      return;
    }
    if (description.length < 5) {
      this._showError(errorMessageElement, 'Deskripsi minimal harus 5 karakter.');
      return;
    }

    try {
      const button = form.querySelector('button[type="submit"]');
      button.textContent = 'Mengunggah...';
      button.disabled = true;

      const formData = new FormData();
      formData.append('photo', photo);
      formData.append('description', description);
      formData.append('lat', lat);
      formData.append('lon', lon);

      await StoryApi.addStory(formData);

      // Reset file yg ditangkap
      this._capturedFile = null;

      alert('Cerita baru berhasil ditambahkan!');
      window.location.hash = '#/stories'; 

    } catch (error) {
      this._showError(errorMessageElement, error.message);
    } finally {
      const button = form.querySelector('button[type="submit"]');
      button.textContent = 'Upload Cerita';
      button.disabled = false;
    }
  }

  _showError(element, message) {
    element.textContent = message;
    element.style.display = 'block';
  }
}

export default AddStoryPage;
