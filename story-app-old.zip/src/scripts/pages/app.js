import routes from '../routes/routes';
import { getActiveRoute } from '../routes/url-parser';

class App {
  #content = null;
  #drawerButton = null;
  #navigationDrawer = null;

  /**
   * @param {{
   * navigationDrawer: HTMLElement,
   * drawerButton: HTMLElement,
   * content: HTMLElement
   * }}
   */
  constructor({ navigationDrawer, drawerButton, content }) {
    this.#content = content;
    this.#drawerButton = drawerButton;
    this.#navigationDrawer = navigationDrawer;

    this._setupDrawer();
  }

  _setupDrawer() {
    // Garis merah akan hilang karena JSDoc di atas
    this.#drawerButton.addEventListener('click', () => {
      this.#navigationDrawer.classList.toggle('open');
    });

    document.body.addEventListener('click', (event) => {
      if (!this.#navigationDrawer.contains(event.target) && !this.#drawerButton.contains(event.target)) {
        this.#navigationDrawer.classList.remove('open');
      }

      this.#navigationDrawer.querySelectorAll('a').forEach((link) => {
        if (link.contains(event.target)) {
          this.#navigationDrawer.classList.remove('open');
        }
      });
    });
  }

  async renderPage() {
    try {
      const url = getActiveRoute();
      const page = routes[url] || routes['/']; // Fallback ke '/'

      if (!page) {
        throw new Error('Halaman tidak ditemukan untuk rute: ' + url);
      }
      
      this.#content.innerHTML = await page.render();
      await page.afterRender();
      
      // Kriteria 4 (Advance): Fokus ke skip-to-content
      const skipToContentLink = document.querySelector('.skip-to-content');
      skipToContentLink.addEventListener('click', (event) => {
        event.preventDefault();
        this.#content.focus();
      });

    } catch (error) {
      console.error('Gagal me-render halaman:', error);
      this.#content.innerHTML = `<h2 style="text-align: center;">Halaman Gagal Dimuat</h2><p style="text-align: center;">Silakan coba kembali atau refresh halaman.</p>`;
    }
  }
}

export default App;
