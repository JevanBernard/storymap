import StoryApi from '../../data/story-api';

class LoginPage {
  async render() {
    return `
      <section class="auth-page">
        <h2 class="auth-page__title">Login</h2>
        <form id="login-form" class="auth-form" novalidate>
          <div class="form-group">
            <!-- Kriteria 4: Label untuk aksesibilitas -->
            <label for="login-email">Email:</label>
            <input type="email" id="login-email" name="email" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="login-password">Password:</label>
            <input type="password" id="login-password" name="password" class="form-control" required>
          </div>
          <button type="submit" class="auth-button">Login</button>
          
          <!-- Pesan Error -->
          <div id="error-message" class="error-message" role="alert" aria-live="assertive"></div>
        </form>
        <p class="auth-redirect">
          Belum punya akun? <a href="#/register">Daftar di sini</a>
        </p>
      </section>
    `;
  }

  // Method afterRender() - Menambahkan event listener
  async afterRender() {
    const loginForm = document.getElementById('login-form');
    const errorMessageElement = document.getElementById('error-message');

    loginForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      
      const email = event.target.email.value;
      const password = event.target.password.value;

      // Reset pesan error
      errorMessageElement.textContent = '';
      errorMessageElement.style.display = 'none';

      // Validasi Input Sederhana
      if (!email || !password) {
        this._showError(errorMessageElement, 'Email dan Password tidak boleh kosong.');
        return;
      }

      try {
        // Tampilkan loading
        event.target.querySelector('button').textContent = 'Memproses...';
        event.target.querySelector('button').disabled = true;

        // Panggil API Login
        await StoryApi.login(email, password);

        // Jika berhasil, redirect ke halaman stories
        alert('Login berhasil!');
        window.location.hash = '#/stories';

      } catch (error) {
        // Pesan Error
        this._showError(errorMessageElement, error.message);
      } finally {
        // Kembalikan tombol ke state normal
        event.target.querySelector('button').textContent = 'Login';
        event.target.querySelector('button').disabled = false;
      }
    });
  }

  _showError(element, message) {
    element.textContent = message;
    element.style.display = 'block';
  }
}

export default LoginPage;