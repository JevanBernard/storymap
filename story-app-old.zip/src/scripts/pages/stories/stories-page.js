import L from 'leaflet';
import StoryApi from '../../data/story-api';

// Impor manual gambar marker Leaflet
import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png';
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';

class StoriesPage {
  constructor() {
    this._map = null;
    delete L.Icon.Default.prototype._getIconUrl;
    L.Icon.Default.mergeOptions({
      iconUrl: markerIcon,
      iconRetinaUrl: markerIcon2x,
      shadowUrl: markerShadow,
    });
  }

  // Method render() - Menyiapkan kerangka HTML
  async render() {
    return `
      <section class="stories-page">
        <h2>Jelajahi Cerita di Peta</h2>
        <p>Lihat cerita dari seluruh penjuru!</p>
        
        <!-- Kriteria 2: Elemen Peta -->
        <div id="map"></div>
        
        <!-- Kriteria 2: Elemen Daftar Cerita -->
        <h3>Daftar Cerita</h3>
        <div id="story-list-container" class="story-list">
          <p>Memuat cerita...</p>
        </div>
      </section>
    `;
  }

  // Method afterRender() - Mengisi konten setelah HTML ada di DOM
  async afterRender() {
    try {
      // 1. Ambil data cerita dari API
      const stories = await StoryApi.getAllStories();
      
      // 2. Inisialisasi Peta
      this._initMap(stories);

      // 3. Render daftar cerita
      this._renderStoryList(stories);

    } catch (error) {
      // Tangani jika token tidak valid/habis
      if (error.message === '401') {
        alert('Sesi Anda habis. Silakan login kembali.');
        window.location.hash = '#/';
      } else {
        // Tampilkan error lain
        const storyContainer = document.getElementById('story-list-container');
        storyContainer.innerHTML = `<p class="story-item story-item--no-image">Gagal memuat cerita: ${error.message}. Coba refresh halaman.</p>`;
      }
    }
  }

  /**
   * Inisialisasi Leaflet Map
   * @param {array} stories - Daftar cerita dari API
   */
  _initMap(stories) {
    // Tentukan koordinat tengah Indonesia
    const centerLat = -2.5489;
    const centerLon = 118.0149;
    
    this._map = L.map('map').setView([centerLat, centerLon], 5);

    // Multiple Tile Layers
    const osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    });

    const stamenTonerLayer = L.tileLayer('https://stamen-tiles-{s}.a.ssl.fastly.net/toner/{z}/{x}/{y}{r}.png', {
      attribution: 'Map tiles by <a href="http://stamen.com">Stamen Design</a>, <a href="http://creativecommons.org/licenses/by/3.0">CC BY 3.0</a> &mdash; Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    });

    const baseMaps = {
      "OpenStreetMap": osmLayer,
      "Mode Gelap (Stamen Toner)": stamenTonerLayer
    };

    L.control.layers(baseMaps).addTo(this._map);
    osmLayer.addTo(this._map);

    // Tambah Marker & Popup 
    stories.forEach(story => {
      // Pastikan cerita punya koordinat
      if (story.lat && story.lon) {
        L.marker([story.lat, story.lon])
          .addTo(this._map)
          .bindPopup(`
            <b>${story.name || 'Tanpa Nama'}</b><br>
            ${story.photoUrl ? `<img src="${story.photoUrl}" alt="Foto untuk ${story.name || ''}" style="width: 100px; margin-top: 5px;">` : ''}
            <p style="font-size: 12px; max-width: 150px; white-space: pre-wrap;">${(story.description || 'Tanpa deskripsi').substring(0, 100)}...</p>
          `);
      }
    });
  }

  /**
   * Render daftar cerita ke DOM
   * @param {array} stories - Daftar cerita dari API
   */
  _renderStoryList(stories) {
    const storyContainer = document.getElementById('story-list-container');
    
    if (stories.length === 0) {
      storyContainer.innerHTML = '<p class="story-item story-item--no-image">Belum ada cerita yang diposting.</p>';
      return;
    }

    // Kosongkan container dulu
    storyContainer.innerHTML = '';

    stories.forEach(story => {
      const storyName = story.name || 'Cerita Tanpa Nama';
      const storyDescription = story.description || 'Tidak ada deskripsi.';
      
      const storyItem = document.createElement('article');
      storyItem.classList.add('story-item');

      let storyHTML = '';

      // Cek jika ada URL foto
      if (story.photoUrl) {
        storyHTML = `
          <img src="${story.photoUrl}" alt="Cerita oleh ${storyName}: ${storyDescription.substring(0, 50)}...">
          <div class="story-item__content">
            <h4 class="story-item__title">${storyName}</h4>
            <p class="story-item__description">${storyDescription}</p>
          </div>
        `;
      } else {
        // Jika TIDAK ADA foto, tambahkan class khusus
        storyItem.classList.add('story-item--no-image');
        storyHTML = `
          <div class="story-item__content">
            <h4 class="story-item__title">${storyName}</h4>
            <p class="story-item__description">${storyDescription}</p>
          </div>
        `;
      }

      storyItem.innerHTML = storyHTML;
      storyContainer.appendChild(storyItem);
    });
  }
}

export default StoriesPage;