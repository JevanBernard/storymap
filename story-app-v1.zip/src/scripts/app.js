import routes from './routes/routes';
import { getActiveRoute } from './routes/url-parser';
import { updateNavBasedOnAuth } from './utils/auth-ui';
import StoryApi from './data/story-api';

class App {
  /**
   * @param {HTMLElement} content - Elemen <main> untuk render halaman
   * @param {HTMLElement} drawerButton - Tombol hamburger
   * @param {HTMLElement} navigationDrawer - Menu navigasi
   */
  constructor({ content, drawerButton, navigationDrawer }) {
    this.#content = content;
    this.#drawerButton = drawerButton;
    this.#navigationDrawer = navigationDrawer;

    this._setupDrawer();
    updateNavBasedOnAuth();
  }

  #content = null;
  #drawerButton = null;
  #navigationDrawer = null;

  _setupDrawer() {
    this.#drawerButton.addEventListener('click', (event) => {
      event.stopPropagation();
      this.#navigationDrawer.classList.toggle('open');
    });

    document.body.addEventListener('click', (event) => {
      if (!this.#navigationDrawer.contains(event.target) && !this.#drawerButton.contains(event.target)) {
        this.#navigationDrawer.classList.remove('open');
      }
    });
    
    // Setup link Logout
    const logoutLink = document.getElementById('logout-link');
    logoutLink.addEventListener('click', (event) => {
      event.preventDefault();
      StoryApi.logout();
      updateNavBasedOnAuth(); 
      window.location.hash = '#/';
    });
  }

  async renderPage() {
    const path = window.location.hash.slice(1).toLowerCase() || '/';
    const page = routes[path] || routes['/'];

    // View Transition
    if (document.startViewTransition) {
      document.startViewTransition(async () => {
        this.#content.innerHTML = await page.render();
        await page.afterRender();
      });
    } else {
      // Fallback jika tidak support
      this.#content.innerHTML = await page.render();
      await page.afterRender();
    }
    
    updateNavBasedOnAuth();
    
    this.#navigationDrawer.classList.remove('open');
  }
}

export default App;
