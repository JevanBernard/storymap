// src/scripts/data/story-api.js

const STORY_API_BASE_URL = 'https://story-api.dicoding.dev/v1';

class StoryApi {
  /**
   * Menyimpan token ke sessionStorage
   * @param {string} token - Token autentikasi
   */
  static _saveToken(token) {
    sessionStorage.setItem('authToken', token);
  }

  /**
   * Mendapatkan token dari sessionStorage
   * @returns {string|null} - Token autentikasi
   */
  static getToken() {
    return sessionStorage.getItem('authToken');
  }

  /**
   * Menghapus token dari sessionStorage (Logout)
   */
  static logout() {
    sessionStorage.removeItem('authToken');
  }

  /**
   * Melakukan login
   * @param {string} email - Email pengguna
   * @param {string} password - Password pengguna
   * @returns {Promise<object>} - Hasil response JSON
   */
  static async login(email, password) {
    try {
      const response = await fetch(`${STORY_API_BASE_URL}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const responseJson = await response.json();

      if (responseJson.error) {
        throw new Error(responseJson.message);
      }

      // Simpan token jika login berhasil
      if (responseJson.loginResult && responseJson.loginResult.token) {
        this._saveToken(responseJson.loginResult.token);
      }

      return responseJson;
    } catch (error) {
      console.error('Login failed:', error.message);
      throw error;
    }
  }

  /**
   * Melakukan registrasi
   * @param {string} name - Nama pengguna
   * @param {string} email - Email pengguna
   * @param {string} password - Password pengguna
   * @returns {Promise<object>} - Hasil response JSON
   */
  static async register(name, email, password) {
    try {
      const response = await fetch(`${STORY_API_BASE_URL}/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password }),
      });

      const responseJson = await response.json();

      if (responseJson.error) {
        throw new Error(responseJson.message);
      }

      return responseJson;
    } catch (error) {
      console.error('Register failed:', error.message);
      throw error;
    }
  }

  /**
   * Mendapatkan semua stories (butuh token)
   * @returns {Promise<array>} - Daftar cerita
   */
  static async getAllStories() {
    const token = this.getToken();
    if (!token) {
      // 401 Unauthorized - Token tidak ada
      throw new Error('401');
    }

    try {
      const response = await fetch(`${STORY_API_BASE_URL}/stories`, {
        method: 'GET',
        headers: { 'Authorization': `Bearer ${token}` },
      });
      
      if (response.status === 401) {
         // Token tidak valid
        this.logout();
        throw new Error('401');
      }

      const responseJson = await response.json();

      if (responseJson.error) {
        throw new Error(responseJson.message);
      }

      return responseJson.listStory; // Kembalikan array 'listStory'
    } catch (error) {
      console.error('Failed to fetch stories:', error.message);
      throw error;
    }
  }

  /**
   * Menambahkan cerita baru
   * @param {FormData} formData - Data form (photo, description, lat, lon)
   * @returns {Promise<object>}
   */
  static async addStory(formData) {
    const token = this.getToken();
    if (!token) {
      throw new Error('401');
    }

    try {
      const response = await fetch(`${STORY_API_BASE_URL}/stories`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      });
      
      if (response.status === 401) {
        this.logout();
        throw new Error('401');
      }

      const responseJson = await response.json();

      if (responseJson.error) {
        throw new Error(responseJson.message);
      }

      return responseJson;
    } catch (error) {
      console.error('Failed to add story:', error.message);
      throw error;
    }
  }
}

export default StoryApi;

