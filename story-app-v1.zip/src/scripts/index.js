import 'leaflet/dist/leaflet.css';
import '../styles/styles.css'; 
import App from './app';

document.addEventListener('DOMContentLoaded', () => {
  const app = new App({
    drawerButton: document.getElementById('drawer-button'),
    navigationDrawer: document.getElementById('navigation-drawer'),
    content: document.getElementById('app-content'),
  });

  window.addEventListener('hashchange', () => {
    app.renderPage();
  });
  window.addEventListener('load', () => {
    app.renderPage();
  });
});