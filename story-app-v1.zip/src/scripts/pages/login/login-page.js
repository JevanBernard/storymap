// src/pages/login/login-page.js
// Diperbarui untuk memanggil helper UI

import StoryApi from '../../data/story-api';
import { updateNavBasedOnAuth } from '../../utils/auth-ui'; // Impor helper UI

class LoginPage {
  async render() {
    return `
      <section class="auth-page">
        <h2 class="auth-page__title">Login</h2>
        <form id="login-form" class="auth-form">
          <div class="form-group">
            <label for="login-email">Email:</label>
            <input type="email" id="login-email" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="login-password">Password:</label>
            <input type="password" id="login-password" class="form-control" required>
          </div>
          <button type="submit" class="auth-button" id="login-button">Login</button>
        </form>
        <p class="auth-redirect">
          Belum punya akun? <a href="#/register">Daftar di sini</a>
        </p>
        <div id="error-message" class="error-message"></div>
      </section>
    `;
  }

  async afterRender() {
    const loginForm = document.getElementById('login-form');
    const loginButton = document.getElementById('login-button');
    const errorMessage = document.getElementById('error-message');

    loginForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      
      loginButton.disabled = true;
      loginButton.textContent = 'Memproses...';
      errorMessage.style.display = 'none';

      try {
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;
        
        await StoryApi.login(email, password);
        
        // Note: Panggil helper UI untuk update nav
        updateNavBasedOnAuth();
        
        // Redirect ke halaman stories
        window.location.hash = '#/stories';

      } catch (error) {
        errorMessage.textContent = `Login Gagal: ${error.message}`;
        errorMessage.style.display = 'block';
      } finally {
        loginButton.disabled = false;
        loginButton.textContent = 'Login';
      }
    });
  }
}

export default LoginPage;

