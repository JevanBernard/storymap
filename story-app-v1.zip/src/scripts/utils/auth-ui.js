import StoryApi from '../data/story-api';

const updateNavBasedOnAuth = () => {
  const token = StoryApi.getToken();
  
  const guestLinks = document.querySelectorAll('[data-auth="guest"]');
  const userLinks = document.querySelectorAll('[data-auth="user"]');

  if (token) {
    // User logged in
    guestLinks.forEach(link => link.style.display = 'none');
    userLinks.forEach(link => link.style.display = 'list-item');
  } else {
    // User logged out (guest)
    guestLinks.forEach(link => link.style.display = 'list-item');
    userLinks.forEach(link => link.style.display = 'none');
  }
};

export { updateNavBasedOnAuth };